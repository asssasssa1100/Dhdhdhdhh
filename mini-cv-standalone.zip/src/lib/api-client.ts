import { useMutation, useQuery } from '@tanstack/react-query';
import type {
  MutationFunction, QueryFunction, QueryKey,
  UseMutationOptions, UseMutationResult,
  UseQueryOptions, UseQueryResult
} from '@tanstack/react-query';
import type { Cv, CvInput, CvPatch, CvStats } from './api-types';
import { customFetch } from './custom-fetch';
import type { ErrorType, BodyType } from './custom-fetch';

type AwaitedInput<T> = PromiseLike<T> | T;
type Awaited<O> = O extends AwaitedInput<infer T> ? T : never;
type SecondParameter<T extends (...args: never) => unknown> = Parameters<T>[1];

// ── Create CV ──────────────────────────────────────────────────
export const createCv = async (cvInput: CvInput, options?: RequestInit): Promise<Cv> =>
  customFetch<Cv>(`/api/cvs`, { ...options, method: 'POST', headers: { 'Content-Type': 'application/json', ...options?.headers }, body: JSON.stringify(cvInput) });

export const useCreateCv = <TError = ErrorType<void>, TContext = unknown>(
  options?: { mutation?: UseMutationOptions<Awaited<ReturnType<typeof createCv>>, TError, { data: BodyType<CvInput> }, TContext> }
): UseMutationResult<Awaited<ReturnType<typeof createCv>>, TError, { data: BodyType<CvInput> }, TContext> => {
  const mutationFn: MutationFunction<Awaited<ReturnType<typeof createCv>>, { data: BodyType<CvInput> }> = ({ data }) => createCv(data);
  return useMutation({ mutationFn, ...options?.mutation });
};

// ── Get CV ─────────────────────────────────────────────────────
export const getCv = async (shareId: string, options?: RequestInit): Promise<Cv> =>
  customFetch<Cv>(`/api/cvs/${shareId}`, { ...options, method: 'GET' });

export const getGetCvQueryKey = (shareId: string) => [`/api/cvs/${shareId}`] as const;

export function useGetCv<TData = Awaited<ReturnType<typeof getCv>>, TError = ErrorType<void>>(
  shareId: string,
  options?: { query?: UseQueryOptions<Awaited<ReturnType<typeof getCv>>, TError, TData>; request?: SecondParameter<typeof customFetch> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const { query: queryOptions } = options ?? {};
  const queryKey = queryOptions?.queryKey ?? getGetCvQueryKey(shareId);
  const queryFn: QueryFunction<Awaited<ReturnType<typeof getCv>>> = ({ signal }) => getCv(shareId, { signal });
  const query = useQuery({ queryKey, queryFn, enabled: !!shareId, ...queryOptions }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  return { ...query, queryKey };
}

// ── Update CV ──────────────────────────────────────────────────
export const updateCv = async (shareId: string, cvPatch: CvPatch, options?: RequestInit): Promise<Cv> =>
  customFetch<Cv>(`/api/cvs/${shareId}`, { ...options, method: 'PATCH', headers: { 'Content-Type': 'application/json', ...options?.headers }, body: JSON.stringify(cvPatch) });

export const useUpdateCv = <TError = ErrorType<void>, TContext = unknown>(
  options?: { mutation?: UseMutationOptions<Awaited<ReturnType<typeof updateCv>>, TError, { shareId: string; data: BodyType<CvPatch> }, TContext> }
): UseMutationResult<Awaited<ReturnType<typeof updateCv>>, TError, { shareId: string; data: BodyType<CvPatch> }, TContext> => {
  const mutationFn: MutationFunction<Awaited<ReturnType<typeof updateCv>>, { shareId: string; data: BodyType<CvPatch> }> = ({ shareId, data }) => updateCv(shareId, data);
  return useMutation({ mutationFn, ...options?.mutation });
};

// ── Delete CV ──────────────────────────────────────────────────
export const deleteCv = async (shareId: string, options?: RequestInit): Promise<void> =>
  customFetch<void>(`/api/cvs/${shareId}`, { ...options, method: 'DELETE' });

export const useDeleteCv = <TError = ErrorType<void>, TContext = unknown>(
  options?: { mutation?: UseMutationOptions<Awaited<ReturnType<typeof deleteCv>>, TError, { shareId: string }, TContext> }
): UseMutationResult<Awaited<ReturnType<typeof deleteCv>>, TError, { shareId: string }, TContext> => {
  const mutationFn: MutationFunction<Awaited<ReturnType<typeof deleteCv>>, { shareId: string }> = ({ shareId }) => deleteCv(shareId);
  return useMutation({ mutationFn, ...options?.mutation });
};

// ── Record View ────────────────────────────────────────────────
export const recordCvView = async (shareId: string, options?: RequestInit): Promise<void> =>
  customFetch<void>(`/api/cvs/${shareId}/views`, { ...options, method: 'POST' });

export const useRecordCvView = <TError = ErrorType<unknown>, TContext = unknown>(
  options?: { mutation?: UseMutationOptions<Awaited<ReturnType<typeof recordCvView>>, TError, { shareId: string }, TContext> }
): UseMutationResult<Awaited<ReturnType<typeof recordCvView>>, TError, { shareId: string }, TContext> => {
  const mutationFn: MutationFunction<Awaited<ReturnType<typeof recordCvView>>, { shareId: string }> = ({ shareId }) => recordCvView(shareId);
  return useMutation({ mutationFn, ...options?.mutation });
};

// ── Get CV Stats ───────────────────────────────────────────────
export const getCvStats = async (shareId: string, options?: RequestInit): Promise<CvStats> =>
  customFetch<CvStats>(`/api/cvs/${shareId}/stats`, { ...options, method: 'GET' });

export const getGetCvStatsQueryKey = (shareId: string) => [`/api/cvs/${shareId}/stats`] as const;

export function useGetCvStats<TData = Awaited<ReturnType<typeof getCvStats>>, TError = ErrorType<void>>(
  shareId: string,
  options?: { query?: UseQueryOptions<Awaited<ReturnType<typeof getCvStats>>, TError, TData> }
): UseQueryResult<TData, TError> & { queryKey: QueryKey } {
  const { query: queryOptions } = options ?? {};
  const queryKey = queryOptions?.queryKey ?? getGetCvStatsQueryKey(shareId);
  const queryFn: QueryFunction<Awaited<ReturnType<typeof getCvStats>>> = ({ signal }) => getCvStats(shareId, { signal });
  const query = useQuery({ queryKey, queryFn, enabled: !!shareId, ...queryOptions }) as UseQueryResult<TData, TError> & { queryKey: QueryKey };
  return { ...query, queryKey };
}
