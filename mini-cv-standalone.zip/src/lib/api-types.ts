export interface HealthStatus { status: string; }
export interface Skill { name: string; level?: string | null; }
export interface Experience {
  title: string; company: string;
  startDate?: string | null; endDate?: string | null; description?: string | null;
}
export interface Education {
  degree: string; institution: string;
  startDate?: string | null; endDate?: string | null;
}
export interface SocialLink { platform: string; url: string; }
export interface Cv {
  id: number; shareId: string; name: string; jobTitle: string;
  bio?: string | null; avatarUrl?: string | null; email?: string | null;
  phone?: string | null; location?: string | null; website?: string | null;
  skills?: Skill[]; experiences?: Experience[]; education?: Education[];
  socialLinks?: SocialLink[]; template: string; colorTheme: string;
  language: string; darkMode?: boolean; viewCount?: number;
  createdAt: string; updatedAt: string;
}
export interface CvInput {
  name: string; jobTitle: string; bio?: string; avatarUrl?: string;
  email?: string; phone?: string; location?: string; website?: string;
  skills?: Skill[]; experiences?: Experience[]; education?: Education[];
  socialLinks?: SocialLink[]; template?: string; colorTheme?: string;
  language?: string; darkMode?: boolean;
}
export interface CvPatch {
  name?: string; jobTitle?: string; bio?: string; avatarUrl?: string;
  email?: string; phone?: string; location?: string; website?: string;
  skills?: Skill[]; experiences?: Experience[]; education?: Education[];
  socialLinks?: SocialLink[]; template?: string; colorTheme?: string;
  language?: string; darkMode?: boolean;
}
export interface CvStats { shareId: string; viewCount: number; createdAt: string; }
