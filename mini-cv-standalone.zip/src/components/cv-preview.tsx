import { memo } from "react";
import type { CvInput } from "@/lib/api-types";
import { getThemeStyle, getPlatformIcon } from "../lib/cv-utils";
import { MapPin, Mail, Phone, Globe } from "lucide-react";

type CvPreviewProps = {
  data: Partial<CvInput>;
};

export const CvPreview = memo(({ data }: CvPreviewProps) => {
  const {
    name = "Your Name",
    jobTitle = "Your Job Title",
    bio = "",
    avatarUrl,
    email,
    phone,
    location,
    website,
    skills = [],
    experiences = [],
    education = [],
    socialLinks = [],
    template = "minimal",
    colorTheme = "blue",
    language = "en",
    darkMode = false,
  } = data;

  const isRtl = language === "ar";
  const dir = isRtl ? "rtl" : "ltr";

  // Base container class based on template and dark mode
  let containerClass = "cv-print-container w-full h-full min-h-[800px] overflow-hidden bg-white text-gray-900 transition-colors duration-300";
  if (darkMode) {
    containerClass = "cv-print-container w-full h-full min-h-[800px] overflow-hidden bg-gray-950 text-gray-100 transition-colors duration-300";
  }

  // Template renderers
  const renderMinimal = () => (
    <div className="flex flex-col md:flex-row h-full min-h-[800px]">
      {/* Sidebar */}
      <aside className={`w-full md:w-1/3 p-8 border-r ${darkMode ? 'border-gray-800 bg-gray-900/50' : 'border-gray-200 bg-gray-50/50'}`}>
        <div className="flex flex-col items-center text-center space-y-4">
          {avatarUrl && (
            <img
              src={avatarUrl}
              alt={name}
              className="w-32 h-32 rounded-full object-cover border-4"
              style={{ borderColor: "var(--theme-color)" }}
            />
          )}
          <div>
            <h1 className="text-2xl font-bold tracking-tight">{name}</h1>
            <p className="font-medium mt-1" style={{ color: "var(--theme-color)" }}>{jobTitle}</p>
          </div>
        </div>

        <div className="mt-8 space-y-6">
          {(email || phone || location || website) && (
            <div className="space-y-3">
              <h2 className={`text-sm font-semibold uppercase tracking-wider ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Contact</h2>
              <div className="space-y-2 text-sm">
                {email && <div className="flex items-center gap-2"><Mail size={14} style={{ color: "var(--theme-color)" }} /> <span>{email}</span></div>}
                {phone && <div className="flex items-center gap-2"><Phone size={14} style={{ color: "var(--theme-color)" }} /> <span>{phone}</span></div>}
                {location && <div className="flex items-center gap-2"><MapPin size={14} style={{ color: "var(--theme-color)" }} /> <span>{location}</span></div>}
                {website && <div className="flex items-center gap-2"><Globe size={14} style={{ color: "var(--theme-color)" }} /> <span>{website}</span></div>}
              </div>
            </div>
          )}

          {socialLinks && socialLinks.length > 0 && (
            <div className="space-y-3">
              <h2 className={`text-sm font-semibold uppercase tracking-wider ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Social</h2>
              <div className="flex flex-wrap gap-3">
                {socialLinks.map((link, idx) => {
                  const Icon = getPlatformIcon(link.platform);
                  return (
                    <a key={idx} href={link.url} target="_blank" rel="noreferrer" className="opacity-80 hover:opacity-100 transition-opacity">
                      <Icon size={20} style={{ color: "var(--theme-color)" }} />
                    </a>
                  );
                })}
              </div>
            </div>
          )}

          {skills && skills.length > 0 && (
            <div className="space-y-3">
              <h2 className={`text-sm font-semibold uppercase tracking-wider ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>Skills</h2>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, idx) => (
                  <span
                    key={idx}
                    className={`text-xs px-2.5 py-1 rounded-full border`}
                    style={{ borderColor: "var(--theme-color)", color: "var(--theme-color)" }}
                  >
                    {skill.name}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="w-full md:w-2/3 p-8 md:p-12 space-y-10">
        {bio && (
          <section>
            <h2 className="text-xl font-bold mb-4" style={{ color: "var(--theme-color)" }}>About Me</h2>
            <p className={`leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{bio}</p>
          </section>
        )}

        {experiences && experiences.length > 0 && (
          <section>
            <h2 className="text-xl font-bold mb-6" style={{ color: "var(--theme-color)" }}>Experience</h2>
            <div className="space-y-6">
              {experiences.map((exp, idx) => (
                <div key={idx} className="relative pl-4 border-l-2" style={{ borderColor: "var(--theme-color)" }}>
                  <div className="absolute w-2 h-2 rounded-full -left-[5px] top-1.5" style={{ backgroundColor: "var(--theme-color)" }}></div>
                  <h3 className="font-bold">{exp.title}</h3>
                  <div className={`text-sm font-medium mb-2 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    {exp.company} {exp.startDate && `• ${exp.startDate}`} {exp.endDate && `- ${exp.endDate}`}
                  </div>
                  {exp.description && <p className={`text-sm ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{exp.description}</p>}
                </div>
              ))}
            </div>
          </section>
        )}

        {education && education.length > 0 && (
          <section>
            <h2 className="text-xl font-bold mb-6" style={{ color: "var(--theme-color)" }}>Education</h2>
            <div className="space-y-6">
              {education.map((edu, idx) => (
                <div key={idx}>
                  <h3 className="font-bold">{edu.degree}</h3>
                  <div className={`text-sm font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                    {edu.institution} {edu.startDate && `• ${edu.startDate}`} {edu.endDate && `- ${edu.endDate}`}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );

  const renderModern = () => (
    <div className="h-full min-h-[800px]">
      <header className="px-10 py-16 relative overflow-hidden" style={{ background: `linear-gradient(135deg, var(--theme-color) 0%, transparent 100%)` }}>
        <div className={`absolute inset-0 opacity-90 ${darkMode ? 'bg-gray-950' : 'bg-white'}`}></div>
        <div className="relative z-10 flex flex-col md:flex-row items-center md:items-start gap-8">
          {avatarUrl && (
            <img src={avatarUrl} alt={name} className="w-28 h-28 rounded-2xl object-cover shadow-lg" />
          )}
          <div className="text-center md:text-left flex-1">
            <h1 className="text-4xl font-extrabold tracking-tight">{name}</h1>
            <p className="text-xl mt-2 font-medium" style={{ color: "var(--theme-color)" }}>{jobTitle}</p>
            {bio && <p className={`mt-4 max-w-2xl leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{bio}</p>}
          </div>
        </div>
      </header>

      <div className="p-10 grid grid-cols-1 md:grid-cols-3 gap-10">
        <aside className="space-y-8">
          {(email || phone || location || website) && (
            <div className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
              <h2 className="text-lg font-bold mb-4" style={{ color: "var(--theme-color)" }}>Contact</h2>
              <div className="space-y-3 text-sm">
                {email && <div className="flex items-center gap-3"><Mail size={16} className="opacity-70" /> <span>{email}</span></div>}
                {phone && <div className="flex items-center gap-3"><Phone size={16} className="opacity-70" /> <span>{phone}</span></div>}
                {location && <div className="flex items-center gap-3"><MapPin size={16} className="opacity-70" /> <span>{location}</span></div>}
                {website && <div className="flex items-center gap-3"><Globe size={16} className="opacity-70" /> <span>{website}</span></div>}
              </div>
            </div>
          )}

          {skills && skills.length > 0 && (
            <div>
              <h2 className="text-lg font-bold mb-4" style={{ color: "var(--theme-color)" }}>Skills</h2>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill, idx) => (
                  <span key={idx} className={`text-sm px-3 py-1.5 rounded-md ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`}>
                    {skill.name}
                  </span>
                ))}
              </div>
            </div>
          )}

          {socialLinks && socialLinks.length > 0 && (
            <div>
              <h2 className="text-lg font-bold mb-4" style={{ color: "var(--theme-color)" }}>Social</h2>
              <div className="flex flex-col gap-3">
                {socialLinks.map((link, idx) => {
                  const Icon = getPlatformIcon(link.platform);
                  return (
                    <a key={idx} href={link.url} target="_blank" rel="noreferrer" className="flex items-center gap-3 text-sm opacity-80 hover:opacity-100">
                      <Icon size={16} /> <span>{link.platform}</span>
                    </a>
                  );
                })}
              </div>
            </div>
          )}
        </aside>

        <main className="md:col-span-2 space-y-10">
          {experiences && experiences.length > 0 && (
            <section>
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <span className="w-8 h-1 rounded-full" style={{ backgroundColor: "var(--theme-color)" }}></span>
                Experience
              </h2>
              <div className="space-y-8">
                {experiences.map((exp, idx) => (
                  <div key={idx} className="group">
                    <div className="flex flex-col md:flex-row md:items-baseline justify-between mb-2">
                      <h3 className="text-lg font-bold">{exp.title}</h3>
                      <span className={`text-sm font-medium px-3 py-1 rounded-full ${darkMode ? 'bg-gray-800' : 'bg-gray-100'}`} style={{ color: "var(--theme-color)" }}>
                        {exp.startDate} {exp.endDate && `- ${exp.endDate}`}
                      </span>
                    </div>
                    <div className={`font-medium mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>{exp.company}</div>
                    {exp.description && <p className={`leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{exp.description}</p>}
                  </div>
                ))}
              </div>
            </section>
          )}

          {education && education.length > 0 && (
            <section>
              <h2 className="text-2xl font-bold mb-6 flex items-center gap-3">
                <span className="w-8 h-1 rounded-full" style={{ backgroundColor: "var(--theme-color)" }}></span>
                Education
              </h2>
              <div className="space-y-6">
                {education.map((edu, idx) => (
                  <div key={idx} className={`p-6 rounded-2xl ${darkMode ? 'bg-gray-900/50' : 'bg-gray-50'}`}>
                    <h3 className="text-lg font-bold">{edu.degree}</h3>
                    <div className={`mt-1 font-medium ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {edu.institution}
                    </div>
                    {(edu.startDate || edu.endDate) && (
                      <div className="mt-2 text-sm opacity-70">
                        {edu.startDate} {edu.endDate && `- ${edu.endDate}`}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}
        </main>
      </div>
    </div>
  );

  const renderBold = () => (
    <div className="h-full min-h-[800px] flex flex-col">
      <header className="px-10 py-16 text-center border-b-8" style={{ borderColor: "var(--theme-color)", backgroundColor: darkMode ? '#111827' : '#0f172a', color: 'white' }}>
        {avatarUrl && (
          <img src={avatarUrl} alt={name} className="w-24 h-24 rounded-full object-cover mx-auto mb-6 ring-4 ring-white/20" />
        )}
        <h1 className="text-5xl font-black uppercase tracking-widest">{name}</h1>
        <p className="text-xl mt-3 font-semibold tracking-widest" style={{ color: "var(--theme-color)" }}>{jobTitle}</p>
        
        {(email || phone || location || website) && (
          <div className="flex flex-wrap justify-center gap-6 mt-8 text-sm font-medium opacity-80">
            {email && <div className="flex items-center gap-2"><Mail size={16} /> <span>{email}</span></div>}
            {phone && <div className="flex items-center gap-2"><Phone size={16} /> <span>{phone}</span></div>}
            {location && <div className="flex items-center gap-2"><MapPin size={16} /> <span>{location}</span></div>}
            {website && <div className="flex items-center gap-2"><Globe size={16} /> <span>{website}</span></div>}
          </div>
        )}
      </header>

      <div className="flex-1 p-10 max-w-5xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12">
        <main className="lg:col-span-8 space-y-12">
          {bio && (
            <section>
              <h2 className="text-3xl font-black uppercase mb-4" style={{ color: "var(--theme-color)" }}>Profile</h2>
              <p className={`text-lg font-medium leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-700'}`}>{bio}</p>
            </section>
          )}

          {experiences && experiences.length > 0 && (
            <section>
              <h2 className="text-3xl font-black uppercase mb-8" style={{ color: "var(--theme-color)" }}>Experience</h2>
              <div className="space-y-10">
                {experiences.map((exp, idx) => (
                  <div key={idx}>
                    <h3 className="text-xl font-bold uppercase">{exp.title}</h3>
                    <div className={`text-sm font-bold uppercase tracking-wider mt-1 mb-3 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {exp.company} // {exp.startDate} {exp.endDate && `- ${exp.endDate}`}
                    </div>
                    {exp.description && <p className={`leading-relaxed ${darkMode ? 'text-gray-300' : 'text-gray-600'}`}>{exp.description}</p>}
                  </div>
                ))}
              </div>
            </section>
          )}

          {education && education.length > 0 && (
            <section>
              <h2 className="text-3xl font-black uppercase mb-8" style={{ color: "var(--theme-color)" }}>Education</h2>
              <div className="space-y-8">
                {education.map((edu, idx) => (
                  <div key={idx}>
                    <h3 className="text-xl font-bold uppercase">{edu.degree}</h3>
                    <div className={`text-sm font-bold uppercase tracking-wider mt-1 ${darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {edu.institution} // {edu.startDate} {edu.endDate && `- ${edu.endDate}`}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          )}
        </main>

        <aside className="lg:col-span-4 space-y-12">
          {skills && skills.length > 0 && (
            <section>
              <h2 className="text-3xl font-black uppercase mb-6" style={{ color: "var(--theme-color)" }}>Skills</h2>
              <div className="flex flex-col gap-4">
                {skills.map((skill, idx) => (
                  <div key={idx} className="flex flex-col gap-1">
                    <span className="font-bold uppercase tracking-wider">{skill.name}</span>
                    {skill.level && (
                      <span className={`text-xs font-bold uppercase ${darkMode ? 'text-gray-500' : 'text-gray-400'}`}>{skill.level}</span>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {socialLinks && socialLinks.length > 0 && (
            <section>
              <h2 className="text-3xl font-black uppercase mb-6" style={{ color: "var(--theme-color)" }}>Network</h2>
              <div className="flex gap-4 flex-wrap">
                {socialLinks.map((link, idx) => {
                  const Icon = getPlatformIcon(link.platform);
                  return (
                    <a key={idx} href={link.url} target="_blank" rel="noreferrer" className={`p-4 rounded-xl ${darkMode ? 'bg-gray-900' : 'bg-gray-100'} hover:scale-110 transition-transform`}>
                      <Icon size={24} style={{ color: "var(--theme-color)" }} />
                    </a>
                  );
                })}
              </div>
            </section>
          )}
        </aside>
      </div>
    </div>
  );

  return (
    <div 
      className={containerClass} 
      dir={dir} 
      style={{ ...getThemeStyle(colorTheme), fontFamily: isRtl ? 'var(--font-arabic)' : 'var(--font-sans)' }}
    >
      {template === "minimal" && renderMinimal()}
      {template === "modern" && renderModern()}
      {template === "bold" && renderBold()}
    </div>
  );
});

CvPreview.displayName = "CvPreview";
