import { useEffect } from "react";
import { useRoute } from "wouter";
import { useGetCv, useRecordCvView } from "@/lib/api-client";
import { CvPreview } from "@/components/cv-preview";
import { Button } from "@/components/ui/button";
import { Download, Share2, QrCode, PenSquare, ArrowLeft } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { QRCodeSVG } from "qrcode.react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function CvView() {
  const [, params] = useRoute("/cv/:shareId");
  const shareId = params?.shareId || "";

  const { data: cv, isLoading, isError } = useGetCv(shareId, { query: { enabled: !!shareId, queryKey: ["getCv", shareId] } });
  const recordView = useRecordCvView();

  useEffect(() => { if (shareId) recordView.mutate({ shareId }); }, [shareId]);

  const handlePrint = () => window.print();
  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: "Link copied", description: "CV link copied to clipboard." });
  };

  if (isLoading) return (
    <div className="min-h-screen bg-muted/30 p-8 flex items-center justify-center">
      <div className="w-full max-w-4xl aspect-[1/1.4] bg-background rounded-2xl shadow-sm border p-8 flex flex-col gap-8">
        <Skeleton className="h-32 w-full rounded-xl" />
        <div className="grid grid-cols-3 gap-8"><div className="col-span-1 space-y-4"><Skeleton className="h-6 w-24" /><Skeleton className="h-4 w-full" /></div><div className="col-span-2 space-y-6"><Skeleton className="h-8 w-48" /><Skeleton className="h-24 w-full" /></div></div>
      </div>
    </div>
  );

  if (isError || !cv) return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
      <h1 className="text-3xl font-bold mb-2">CV not found</h1>
      <p className="text-muted-foreground mb-6">This link might be invalid or the CV was deleted.</p>
      <Link href="/"><Button>Return Home</Button></Link>
    </div>
  );

  const shareUrl = window.location.href;
  return (
    <div className="min-h-screen bg-muted/30 flex flex-col relative print:bg-transparent print:min-h-0">
      <div className="fixed top-6 left-6 z-50 no-print"><Link href="/"><Button variant="outline" size="icon" className="rounded-full shadow-sm bg-background/80 backdrop-blur-md"><ArrowLeft className="w-4 h-4" /></Button></Link></div>
      <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 p-2 bg-background/80 backdrop-blur-md border rounded-full shadow-lg no-print">
        <Button variant="ghost" size="sm" className="rounded-full px-4" onClick={handlePrint}><Download className="w-4 h-4 mr-2" /> PDF</Button>
        <div className="w-px h-6 bg-border mx-1" />
        <Button variant="ghost" size="sm" className="rounded-full px-4" onClick={handleShare}><Share2 className="w-4 h-4 mr-2" /> Share</Button>
        <Popover>
          <PopoverTrigger asChild><Button variant="ghost" size="icon" className="rounded-full"><QrCode className="w-4 h-4" /></Button></PopoverTrigger>
          <PopoverContent className="w-auto p-4" align="center" sideOffset={16}><div className="bg-white p-2 rounded-lg"><QRCodeSVG value={shareUrl} size={150} level="H" includeMargin /></div><p className="text-center text-xs mt-3 text-muted-foreground font-medium">Scan to view CV</p></PopoverContent>
        </Popover>
        <div className="w-px h-6 bg-border mx-1" />
        <Link href={`/cv/${shareId}/edit`}><Button size="sm" className="rounded-full px-4 hover-elevate"><PenSquare className="w-4 h-4 mr-2" /> Edit</Button></Link>
      </div>
      <main className="flex-1 flex justify-center p-0 md:p-8 print:p-0">
        <div className="w-full max-w-[1000px] shadow-2xl md:rounded-2xl overflow-hidden border border-border/50 print:shadow-none print:border-none print:rounded-none bg-background relative isolate"><CvPreview data={cv} /></div>
      </main>
    </div>
  );
}
