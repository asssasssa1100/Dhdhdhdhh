import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateCv } from "@/lib/api-client";
import { defaultCvData } from "@/lib/cv-defaults";
import { CvEditorForm } from "@/components/cv-editor-form";
import { CvPreview } from "@/components/cv-preview";
import type { CvInput } from "@/lib/api-types";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Check, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Create() {
  const [cvData, setCvData] = useState<CvInput>(defaultCvData);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createCvMutation = useCreateCv();

  const handlePublish = () => {
    createCvMutation.mutate(
      { data: cvData },
      {
        onSuccess: (data) => {
          toast({ title: "CV Created!", description: "Your public link is ready." });
          setLocation(`/cv/${data.shareId}`);
        },
        onError: () => {
          toast({ title: "Error", description: "Failed to create CV. Please try again.", variant: "destructive" });
        }
      }
    );
  };

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <header className="h-16 flex-none border-b flex items-center justify-between px-6 bg-card z-10 relative">
        <div className="flex items-center gap-4">
          <Link href="/"><Button variant="ghost" size="icon" className="rounded-full"><ArrowLeft className="w-4 h-4" /></Button></Link>
          <div className="font-semibold text-lg tracking-tight">Create CV</div>
        </div>
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Button onClick={handlePublish} disabled={createCvMutation.isPending} className="rounded-full shadow-sm hover-elevate px-6">
            {createCvMutation.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Saving...</> : <><Check className="w-4 h-4 mr-2" /> Publish</>}
          </Button>
        </div>
      </header>
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        <div className="w-full md:w-[450px] lg:w-[500px] flex-none h-[50vh] md:h-full border-b md:border-b-0 md:border-r overflow-y-auto bg-muted/10 p-6 custom-scrollbar">
          <CvEditorForm initialData={cvData} onChange={setCvData} />
        </div>
        <div className="flex-1 bg-muted/30 h-[50vh] md:h-full overflow-y-auto p-4 md:p-8 flex justify-center custom-scrollbar">
          <div className="w-full max-w-[900px] shadow-xl md:rounded-xl overflow-hidden border border-border/50 bg-background transition-all">
            <CvPreview data={cvData} />
          </div>
        </div>
      </div>
    </div>
  );
}
