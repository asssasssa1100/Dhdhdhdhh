import { useEffect, useRef, useState } from "react";
import { useUpdateCv, getGetCvQueryKey } from "@/lib/api-client";
import { useQueryClient } from "@tanstack/react-query";
import type { CvPatch } from "@/lib/api-types";
import { useDebounce } from "./use-debounce";
import { toast } from "./use-toast";

export function useCvAutoSave(shareId: string, currentData: CvPatch, delay = 1000) {
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const debouncedData = useDebounce(currentData, delay);
  const updateCvMutation = useUpdateCv();
  const queryClient = useQueryClient();
  const initialMount = useRef(true);
  const lastSavedData = useRef(JSON.stringify(currentData));

  useEffect(() => {
    if (initialMount.current) {
      initialMount.current = false;
      return;
    }
    const dataString = JSON.stringify(debouncedData);
    if (dataString === lastSavedData.current) return;

    setSaveStatus("saving");
    updateCvMutation.mutate(
      { shareId, data: debouncedData },
      {
        onSuccess: (data) => {
          setSaveStatus("saved");
          lastSavedData.current = JSON.stringify(debouncedData);
          queryClient.setQueryData(getGetCvQueryKey(shareId), data);
          setTimeout(() => setSaveStatus("idle"), 2000);
        },
        onError: () => {
          setSaveStatus("error");
          toast({ title: "Failed to save changes", variant: "destructive" });
        }
      }
    );
  }, [debouncedData, shareId]);

  return { saveStatus };
}
