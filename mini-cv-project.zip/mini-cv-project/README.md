# Mini CV Maker

تطبيق ويب لإنشاء سيرة ذاتية احترافية ومشاركتها عبر رابط فريد أو QR Code.

## المميزات

- إنشاء سيرة ذاتية في دقائق
- 3 قوالب مختلفة (Modern, Minimal, Classic)
- ألوان متعددة ودعم الوضع الداكن
- رابط مشاركة فريد لكل CV
- QR Code تلقائي
- تصدير إلى PDF
- PWA (قابل للتثبيت على الهاتف)

## هيكل المشروع

```
mini-cv/
├── artifacts/
│   ├── mini-cv/          # الواجهة الأمامية (React + Vite)
│   │   └── src/
│   │       ├── pages/    # الصفحات الرئيسية
│   │       ├── components/ # مكونات UI
│   │       ├── hooks/    # React Hooks
│   │       └── lib/      # أدوات مساعدة
│   └── api-server/       # الخادم الخلفي (Express)
│       └── src/
│           └── routes/   # مسارات API
├── lib/
│   ├── db/               # قاعدة البيانات (Drizzle ORM)
│   ├── api-spec/         # مواصفة OpenAPI
│   ├── api-zod/          # مخططات Zod المولدة
│   └── api-client-react/ # Hooks مولدة لـ React Query
├── package.json
└── pnpm-workspace.yaml
```

## المتطلبات

- Node.js 20+
- pnpm 9+
- PostgreSQL (DATABASE_URL)

## التشغيل المحلي

```bash
# تثبيت الحزم
pnpm install

# تشغيل الخادم الخلفي
pnpm --filter @workspace/api-server run dev

# تشغيل الواجهة الأمامية (في نافذة أخرى)
pnpm --filter @workspace/mini-cv run dev
```

## متغيرات البيئة المطلوبة

```env
DATABASE_URL=postgresql://user:password@localhost:5432/minicv
SESSION_SECRET=your-secret-key
```

## API Endpoints

| Method | Path | الوصف |
|--------|------|-------|
| GET | /api/healthz | فحص حالة الخادم |
| POST | /api/cvs | إنشاء CV جديد |
| GET | /api/cvs/:shareId | جلب CV |
| PATCH | /api/cvs/:shareId | تعديل CV |
| DELETE | /api/cvs/:shareId | حذف CV |
| POST | /api/cvs/:shareId/views | تسجيل زيارة |
| GET | /api/cvs/:shareId/stats | إحصائيات CV |

## بناء APK عبر GitHub Actions

يمكنك استخدام Capacitor لتحويل التطبيق إلى APK:

1. بناء الواجهة الأمامية: `pnpm --filter @workspace/mini-cv run build`
2. إضافة Capacitor: `npx cap add android`
3. مزامنة: `npx cap sync android`
4. بناء APK عبر Gradle أو GitHub Actions

## التقنيات المستخدمة

- **Frontend**: React 18, Vite, TailwindCSS, shadcn/ui, Framer Motion
- **Backend**: Express 5, Node.js
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod
- **State**: TanStack Query
