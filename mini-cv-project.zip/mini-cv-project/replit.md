# Mini CV Maker

تطبيق يساعد المستخدمين على إنشاء سيرة ذاتية مختصرة (Mini CV) خلال دقائق بطريقة احترافية، مع مشاركة برابط مباشر وتصدير PDF.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm --filter @workspace/mini-cv run dev` — run the frontend
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + shadcn/ui + Framer Motion
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for API contracts)
- `lib/db/src/schema/cvs.ts` — CV table schema
- `artifacts/api-server/src/routes/cvs.ts` — CV API routes
- `artifacts/mini-cv/src/` — Frontend React app
  - `pages/` — Landing, CvEditor, CvView pages
  - `lib/cv-utils.ts` — Platform icons and theme colors

## Architecture decisions

- CVs are identified by a random `shareId` (10-char hex string) — no auth required to create/view CVs
- JSON columns (skills, experiences, education, socialLinks) stored as JSONB in PostgreSQL
- Auto-save uses debounce (~1s) on the editor form to PATCH the CV silently
- PDF export uses browser print with `@media print` CSS to hide everything except the CV card
- QR Code generated client-side using `qrcode.react`

## Product

- Create a Mini CV with name, job title, bio, skills, experience, education, and social links
- Choose from 3 templates (modern/minimal/bold) and 5 color themes
- Arabic/English language support with automatic RTL layout
- Share via unique URL, QR code, or download as PDF
- View count tracking on public CV pages

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- `SiLinkedin` was removed in react-icons v5 — use `Linkedin` from lucide-react instead
- After changing DB schema, run `pnpm run typecheck:libs` before testing API server typecheck
- Always run codegen after changing `openapi.yaml`

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
