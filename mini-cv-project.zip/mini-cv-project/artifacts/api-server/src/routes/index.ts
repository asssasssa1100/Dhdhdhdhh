import { Router, type IRouter } from "express";
import healthRouter from "./health";
import cvsRouter from "./cvs";

const router: IRouter = Router();

router.use(healthRouter);
router.use(cvsRouter);

export default router;
