import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, cvsTable } from "@workspace/db";
import {
  CreateCvBody,
  UpdateCvBody,
  GetCvParams,
  UpdateCvParams,
  DeleteCvParams,
  RecordCvViewParams,
  GetCvStatsParams,
} from "@workspace/api-zod";
import { randomBytes } from "crypto";

const router: IRouter = Router();

function generateShareId(): string {
  return randomBytes(5).toString("hex");
}

function formatCv(cv: typeof cvsTable.$inferSelect) {
  return {
    ...cv,
    skills: Array.isArray(cv.skills) ? cv.skills : [],
    experiences: Array.isArray(cv.experiences) ? cv.experiences : [],
    education: Array.isArray(cv.education) ? cv.education : [],
    socialLinks: Array.isArray(cv.socialLinks) ? cv.socialLinks : [],
    createdAt: cv.createdAt.toISOString(),
    updatedAt: cv.updatedAt.toISOString(),
  };
}

router.post("/cvs", async (req, res): Promise<void> => {
  const parsed = CreateCvBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const shareId = generateShareId();
  const data = parsed.data;

  const [cv] = await db
    .insert(cvsTable)
    .values({
      shareId,
      name: data.name,
      jobTitle: data.jobTitle,
      bio: data.bio ?? null,
      avatarUrl: data.avatarUrl ?? null,
      email: data.email ?? null,
      phone: data.phone ?? null,
      location: data.location ?? null,
      website: data.website ?? null,
      skills: (data.skills as object[]) ?? [],
      experiences: (data.experiences as object[]) ?? [],
      education: (data.education as object[]) ?? [],
      socialLinks: (data.socialLinks as object[]) ?? [],
      template: data.template ?? "modern",
      colorTheme: data.colorTheme ?? "blue",
      language: data.language ?? "en",
      darkMode: data.darkMode ?? false,
    })
    .returning();

  res.status(201).json(formatCv(cv));
});

router.get("/cvs/:shareId", async (req, res): Promise<void> => {
  const params = GetCvParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [cv] = await db
    .select()
    .from(cvsTable)
    .where(eq(cvsTable.shareId, params.data.shareId));

  if (!cv) {
    res.status(404).json({ error: "CV not found" });
    return;
  }

  res.json(formatCv(cv));
});

router.patch("/cvs/:shareId", async (req, res): Promise<void> => {
  const params = UpdateCvParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCvBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const updateData: Record<string, unknown> = {};

  if (data.name !== undefined) updateData.name = data.name;
  if (data.jobTitle !== undefined) updateData.jobTitle = data.jobTitle;
  if (data.bio !== undefined) updateData.bio = data.bio;
  if (data.avatarUrl !== undefined) updateData.avatarUrl = data.avatarUrl;
  if (data.email !== undefined) updateData.email = data.email;
  if (data.phone !== undefined) updateData.phone = data.phone;
  if (data.location !== undefined) updateData.location = data.location;
  if (data.website !== undefined) updateData.website = data.website;
  if (data.skills !== undefined) updateData.skills = data.skills as object[];
  if (data.experiences !== undefined) updateData.experiences = data.experiences as object[];
  if (data.education !== undefined) updateData.education = data.education as object[];
  if (data.socialLinks !== undefined) updateData.socialLinks = data.socialLinks as object[];
  if (data.template !== undefined) updateData.template = data.template;
  if (data.colorTheme !== undefined) updateData.colorTheme = data.colorTheme;
  if (data.language !== undefined) updateData.language = data.language;
  if (data.darkMode !== undefined) updateData.darkMode = data.darkMode;

  const [cv] = await db
    .update(cvsTable)
    .set(updateData)
    .where(eq(cvsTable.shareId, params.data.shareId))
    .returning();

  if (!cv) {
    res.status(404).json({ error: "CV not found" });
    return;
  }

  res.json(formatCv(cv));
});

router.delete("/cvs/:shareId", async (req, res): Promise<void> => {
  const params = DeleteCvParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [cv] = await db
    .delete(cvsTable)
    .where(eq(cvsTable.shareId, params.data.shareId))
    .returning();

  if (!cv) {
    res.status(404).json({ error: "CV not found" });
    return;
  }

  res.sendStatus(204);
});

router.post("/cvs/:shareId/views", async (req, res): Promise<void> => {
  const params = RecordCvViewParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  await db
    .update(cvsTable)
    .set({ viewCount: sql`${cvsTable.viewCount} + 1` })
    .where(eq(cvsTable.shareId, params.data.shareId));

  res.sendStatus(204);
});

router.get("/cvs/:shareId/stats", async (req, res): Promise<void> => {
  const params = GetCvStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [cv] = await db
    .select({
      shareId: cvsTable.shareId,
      viewCount: cvsTable.viewCount,
      createdAt: cvsTable.createdAt,
    })
    .from(cvsTable)
    .where(eq(cvsTable.shareId, params.data.shareId));

  if (!cv) {
    res.status(404).json({ error: "CV not found" });
    return;
  }

  res.json({
    shareId: cv.shareId,
    viewCount: cv.viewCount,
    createdAt: cv.createdAt.toISOString(),
  });
});

export default router;
