import { SiGithub, SiX, SiDribbble, SiBehance, SiInstagram, SiYoutube, SiTwitch } from "react-icons/si";
import { Globe, Linkedin } from "lucide-react";

export const themeColors: Record<string, string> = {
  blue: "hsl(var(--cv-theme-blue))",
  purple: "hsl(var(--cv-theme-purple))",
  green: "hsl(var(--cv-theme-green))",
  orange: "hsl(var(--cv-theme-orange))",
  rose: "hsl(var(--cv-theme-rose))",
};

export const getPlatformIcon = (platform: string) => {
  const p = platform.toLowerCase();
  if (p.includes("github")) return SiGithub;
  if (p.includes("linkedin")) return Linkedin;
  if (p.includes("twitter") || p.includes("x.com")) return SiX;
  if (p.includes("dribbble")) return SiDribbble;
  if (p.includes("behance")) return SiBehance;
  if (p.includes("instagram")) return SiInstagram;
  if (p.includes("youtube")) return SiYoutube;
  if (p.includes("twitch")) return SiTwitch;
  return Globe;
};

export const getThemeStyle = (theme: string) => {
  return {
    "--theme-color": themeColors[theme] || themeColors.blue,
  } as React.CSSProperties;
};
