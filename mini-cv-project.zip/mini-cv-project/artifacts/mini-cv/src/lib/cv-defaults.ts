import { CvInput } from "@workspace/api-client-react/src/generated/api.schemas";

export const defaultCvData: CvInput = {
  name: "Alex Doe",
  jobTitle: "Software Engineer",
  bio: "I build things for the web. Passionate about interfaces, user experience, and scalable systems.",
  avatarUrl: "https://i.pravatar.cc/150?u=alex",
  email: "alex@example.com",
  phone: "+1 234 567 890",
  location: "San Francisco, CA",
  website: "alexdoe.com",
  skills: [
    { name: "React", level: "Expert" },
    { name: "TypeScript", level: "Expert" },
    { name: "Node.js", level: "Advanced" }
  ],
  experiences: [
    {
      title: "Senior Frontend Engineer",
      company: "Tech Corp",
      startDate: "2020",
      endDate: "Present",
      description: "Led the frontend team in rebuilding the core product architecture."
    }
  ],
  education: [
    {
      degree: "B.S. Computer Science",
      institution: "State University",
      startDate: "2016",
      endDate: "2020"
    }
  ],
  socialLinks: [
    { platform: "GitHub", url: "https://github.com/alexdoe" },
    { platform: "LinkedIn", url: "https://linkedin.com/in/alexdoe" }
  ],
  template: "minimal",
  colorTheme: "blue",
  language: "en",
  darkMode: false
};
