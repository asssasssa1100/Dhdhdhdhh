import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, FileText, Sparkles, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { ThemeToggle } from "@/components/theme-toggle";

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="py-6 px-8 flex items-center justify-between border-b border-border/40 backdrop-blur-md sticky top-0 z-50">
        <div className="flex items-center gap-2 font-bold text-xl tracking-tight">
          <div className="w-8 h-8 rounded-lg bg-primary text-primary-foreground flex items-center justify-center">
            <FileText size={18} />
          </div>
          Mini CV
        </div>
        <nav className="flex items-center gap-4">
          <ThemeToggle />
          <Link href="/create">
            <Button className="rounded-full shadow-sm hover-elevate">
              Create yours <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </nav>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center px-6 py-20">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="max-w-3xl mx-auto space-y-8"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-muted text-muted-foreground text-sm font-medium border">
            <Sparkles size={14} className="text-amber-500" />
            <span>The easiest way to share your profile</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter text-balance">
            Your career, <br className="hidden md:block" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600">
              beautifully packaged.
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Create a professional mini CV in minutes. No templates to wrestle with, no formatting nightmares. Just your information, presented perfectly.
          </p>
          
          <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link href="/create">
              <Button size="lg" className="rounded-full h-14 px-8 text-base font-medium hover-elevate w-full sm:w-auto">
                Start Building <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </Link>
          </div>

          <div className="pt-20 grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            <div className="p-6 rounded-2xl bg-card border shadow-sm">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-900/30 text-blue-600 flex items-center justify-center mb-4">
                <Zap size={24} />
              </div>
              <h3 className="font-bold text-lg mb-2">Lightning Fast</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">Fill in a simple form and watch your CV generate in real-time. No sign-up required to start.</p>
            </div>
            <div className="p-6 rounded-2xl bg-card border shadow-sm">
              <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-900/30 text-purple-600 flex items-center justify-center mb-4">
                <Sparkles size={24} />
              </div>
              <h3 className="font-bold text-lg mb-2">Beautifully Designed</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">Three distinct templates, multiple color themes, and automatic dark mode support.</p>
            </div>
            <div className="p-6 rounded-2xl bg-card border shadow-sm">
              <div className="w-12 h-12 rounded-xl bg-green-100 dark:bg-green-900/30 text-green-600 flex items-center justify-center mb-4">
                <FileText size={24} />
              </div>
              <h3 className="font-bold text-lg mb-2">Share or Export</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">Get a unique public URL, generate a QR code, or export directly to a pristine PDF.</p>
            </div>
          </div>
        </motion.div>
      </main>
      
      <footer className="py-8 text-center text-sm text-muted-foreground border-t">
        Built with intentionality.
      </footer>
    </div>
  );
}
