import { useEffect, useState, useRef } from "react";
import { useRoute, useLocation } from "wouter";
import { useGetCv, useGetCvStats, getGetCvQueryKey, useDeleteCv } from "@workspace/api-client-react";
import { useCvAutoSave } from "@/hooks/use-cv-autosave";
import { CvEditorForm } from "@/components/cv-editor-form";
import { CvPreview } from "@/components/cv-preview";
import { CvInput } from "@workspace/api-client-react/src/generated/api.schemas";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Eye, Loader2, BarChart2, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { ThemeToggle } from "@/components/theme-toggle";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";

export default function Edit() {
  const [, params] = useRoute("/cv/:shareId/edit");
  const shareId = params?.shareId || "";
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: cv, isLoading, isError } = useGetCv(shareId, {
    query: { enabled: !!shareId, queryKey: ["getCv", shareId] }
  });

  const { data: stats } = useGetCvStats(shareId, {
    query: { enabled: !!shareId, queryKey: ["getCvStats", shareId] }
  });

  const deleteCv = useDeleteCv();

  const handleDelete = () => {
    deleteCv.mutate({ shareId }, {
      onSuccess: () => {
        toast({ title: "CV deleted successfully" });
        setLocation("/");
      },
      onError: () => {
        toast({ title: "Failed to delete CV", variant: "destructive" });
      }
    });
  };

  const [localData, setLocalData] = useState<CvInput | null>(null);
  const initializedRef = useRef(false);

  useEffect(() => {
    if (cv && !initializedRef.current) {
      // Omit id, shareId, createdAt, updatedAt from localData since they aren't part of CvInput
      const { id, shareId, viewCount, createdAt, updatedAt, ...rest } = cv;
      setLocalData(rest as CvInput);
      initializedRef.current = true;
    }
  }, [cv]);

  const { saveStatus } = useCvAutoSave(shareId, localData || {}, 1000);

  if (isLoading || !localData) {
    return (
      <div className="h-screen flex items-center justify-center bg-background">
        <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="h-screen flex flex-col items-center justify-center text-center px-6">
        <h1 className="text-3xl font-bold mb-2">CV not found</h1>
        <p className="text-muted-foreground mb-6">Unable to load this CV for editing.</p>
        <Link href="/">
          <Button>Return Home</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-background overflow-hidden">
      <header className="h-16 flex-none border-b flex items-center justify-between px-6 bg-card z-10 relative">
        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div className="flex flex-col">
            <span className="font-semibold text-sm md:text-base tracking-tight leading-none">Editing CV</span>
            <span className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
              {saveStatus === 'saving' && <><Loader2 className="w-3 h-3 animate-spin" /> Saving...</>}
              {saveStatus === 'saved' && <><span className="w-2 h-2 rounded-full bg-green-500" /> Saved</>}
              {saveStatus === 'idle' && <span className="opacity-70">All changes saved</span>}
              {saveStatus === 'error' && <span className="text-destructive">Failed to save</span>}
            </span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {stats && (
            <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted text-xs font-medium mr-2">
              <BarChart2 className="w-3.5 h-3.5" />
              {stats.viewCount} views
            </div>
          )}
          <ThemeToggle />
          <Link href={`/cv/${shareId}`}>
            <Button variant="outline" className="rounded-full shadow-sm hover-elevate hidden md:flex">
              <Eye className="w-4 h-4 mr-2" /> View Public
            </Button>
          </Link>
          <Link href={`/cv/${shareId}`}>
            <Button variant="outline" size="icon" className="rounded-full shadow-sm hover-elevate md:hidden">
              <Eye className="w-4 h-4" />
            </Button>
          </Link>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive" size="icon" className="rounded-full shadow-sm hover-elevate">
                <Trash2 className="w-4 h-4" />
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                <AlertDialogDescription>
                  This action cannot be undone. This will permanently delete your CV.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  {deleteCv.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                  Delete CV
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Editor Pane */}
        <div className="w-full md:w-[450px] lg:w-[500px] flex-none h-[50vh] md:h-full border-b md:border-b-0 md:border-r overflow-y-auto bg-muted/10 p-6 custom-scrollbar">
          <CvEditorForm initialData={localData} onChange={setLocalData} />
        </div>

        {/* Preview Pane */}
        <div className="flex-1 bg-muted/30 h-[50vh] md:h-full overflow-y-auto p-4 md:p-8 flex justify-center custom-scrollbar">
          <div className="w-full max-w-[900px] shadow-xl md:rounded-xl overflow-hidden border border-border/50 bg-background transition-all">
            <CvPreview data={localData} />
          </div>
        </div>
      </div>
    </div>
  );
}
