import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { CvInput } from "@workspace/api-client-react/src/generated/api.schemas";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from "@/components/ui/accordion";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, GripVertical } from "lucide-react";
import { useEffect } from "react";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  jobTitle: z.string().min(1, "Job title is required"),
  bio: z.string().optional(),
  avatarUrl: z.string().url("Must be a valid URL").optional().or(z.literal('')),
  email: z.string().email("Must be a valid email").optional().or(z.literal('')),
  phone: z.string().optional(),
  location: z.string().optional(),
  website: z.string().optional(),
  template: z.enum(["modern", "minimal", "bold"]),
  colorTheme: z.enum(["blue", "purple", "green", "orange", "rose"]),
  language: z.enum(["en", "ar"]),
  darkMode: z.boolean(),
  skills: z.array(z.object({
    name: z.string().min(1, "Skill name required"),
    level: z.string().optional()
  })).optional(),
  experiences: z.array(z.object({
    title: z.string().min(1, "Title required"),
    company: z.string().min(1, "Company required"),
    startDate: z.string().optional(),
    endDate: z.string().optional(),
    description: z.string().optional()
  })).optional(),
  education: z.array(z.object({
    degree: z.string().min(1, "Degree required"),
    institution: z.string().min(1, "Institution required"),
    startDate: z.string().optional(),
    endDate: z.string().optional(),
  })).optional(),
  socialLinks: z.array(z.object({
    platform: z.string().min(1, "Platform required"),
    url: z.string().url("Must be a valid URL")
  })).optional(),
});

type CvEditorFormProps = {
  initialData: CvInput;
  onChange: (data: CvInput) => void;
};

export function CvEditorForm({ initialData, onChange }: CvEditorFormProps) {
  const form = useForm<CvInput>({
    resolver: zodResolver(schema),
    defaultValues: initialData,
  });

  const { control, watch, register, formState: { errors } } = form;

  const skillsField = useFieldArray({ control, name: "skills" });
  const expField = useFieldArray({ control, name: "experiences" });
  const eduField = useFieldArray({ control, name: "education" });
  const socialField = useFieldArray({ control, name: "socialLinks" });

  useEffect(() => {
    const subscription = watch((value) => {
      // @ts-ignore - The watch values mostly match the shape unless in partial state
      onChange(value as CvInput);
    });
    return () => subscription.unsubscribe();
  }, [watch, onChange]);

  return (
    <div className="space-y-6">
      <div className="p-5 bg-card border rounded-xl shadow-sm space-y-5">
        <h2 className="font-semibold text-lg">Design Settings</h2>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Template</Label>
            <Controller
              control={control}
              name="template"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select template" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="minimal">Minimal</SelectItem>
                    <SelectItem value="modern">Modern</SelectItem>
                    <SelectItem value="bold">Bold</SelectItem>
                  </SelectContent>
                </Select>
              )}
            />
          </div>
          <div className="space-y-2">
            <Label>Theme Color</Label>
            <Controller
              control={control}
              name="colorTheme"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select color" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="blue">Blue</SelectItem>
                    <SelectItem value="purple">Purple</SelectItem>
                    <SelectItem value="green">Green</SelectItem>
                    <SelectItem value="orange">Orange</SelectItem>
                    <SelectItem value="rose">Rose</SelectItem>
                  </SelectContent>
                </Select>
              )}
            />
          </div>
          <div className="space-y-2">
            <Label>Language</Label>
            <Controller
              control={control}
              name="language"
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger><SelectValue placeholder="Select language" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English (LTR)</SelectItem>
                    <SelectItem value="ar">Arabic (RTL)</SelectItem>
                  </SelectContent>
                </Select>
              )}
            />
          </div>
          <div className="space-y-2 flex flex-col justify-end">
            <div className="flex items-center space-x-2 py-2">
              <Controller
                control={control}
                name="darkMode"
                render={({ field }) => (
                  <Switch checked={!!field.value} onCheckedChange={field.onChange} />
                )}
              />
              <Label>Dark Mode CV</Label>
            </div>
          </div>
        </div>
      </div>

      <Accordion type="multiple" className="w-full space-y-4" defaultValue={["basic"]}>
        <AccordionItem value="basic" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Basic Information
          </AccordionTrigger>
          <AccordionContent className="space-y-4 pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Full Name</Label>
                <Input {...register("name")} placeholder="Jane Doe" />
                {errors.name && <p className="text-destructive text-xs">{errors.name.message}</p>}
              </div>
              <div className="space-y-2">
                <Label>Job Title</Label>
                <Input {...register("jobTitle")} placeholder="Frontend Developer" />
                {errors.jobTitle && <p className="text-destructive text-xs">{errors.jobTitle.message}</p>}
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Bio / Summary</Label>
                <Textarea {...register("bio")} placeholder="A brief professional summary..." rows={3} />
              </div>
              <div className="space-y-2 md:col-span-2">
                <Label>Avatar URL (Optional)</Label>
                <Input {...register("avatarUrl")} placeholder="https://..." />
                {errors.avatarUrl && <p className="text-destructive text-xs">{errors.avatarUrl.message}</p>}
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="contact" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Contact Details
          </AccordionTrigger>
          <AccordionContent className="space-y-4 pb-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Email</Label>
                <Input {...register("email")} placeholder="jane@example.com" type="email" />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input {...register("phone")} placeholder="+1 234 567 890" />
              </div>
              <div className="space-y-2">
                <Label>Location</Label>
                <Input {...register("location")} placeholder="New York, NY" />
              </div>
              <div className="space-y-2">
                <Label>Website</Label>
                <Input {...register("website")} placeholder="janedoe.com" />
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="experience" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Experience
          </AccordionTrigger>
          <AccordionContent className="space-y-6 pb-5">
            {expField.fields.map((field, index) => (
              <div key={field.id} className="p-4 bg-muted/30 border rounded-lg relative group">
                <Button 
                  variant="ghost" size="icon" 
                  className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity text-destructive"
                  onClick={() => expField.remove(index)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
                <div className="grid grid-cols-2 gap-4 pr-8">
                  <div className="space-y-2 col-span-2 md:col-span-1">
                    <Label>Title</Label>
                    <Input {...register(`experiences.${index}.title`)} placeholder="Software Engineer" />
                  </div>
                  <div className="space-y-2 col-span-2 md:col-span-1">
                    <Label>Company</Label>
                    <Input {...register(`experiences.${index}.company`)} placeholder="Tech Corp" />
                  </div>
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input {...register(`experiences.${index}.startDate`)} placeholder="Jan 2020" />
                  </div>
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input {...register(`experiences.${index}.endDate`)} placeholder="Present" />
                  </div>
                  <div className="space-y-2 col-span-2">
                    <Label>Description</Label>
                    <Textarea {...register(`experiences.${index}.description`)} placeholder="What did you do?" rows={2} />
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full border-dashed" onClick={() => expField.append({ title: "", company: "", description: "" })}>
              <Plus className="w-4 h-4 mr-2" /> Add Experience
            </Button>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="education" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Education
          </AccordionTrigger>
          <AccordionContent className="space-y-6 pb-5">
            {eduField.fields.map((field, index) => (
              <div key={field.id} className="p-4 bg-muted/30 border rounded-lg relative group">
                <Button 
                  variant="ghost" size="icon" 
                  className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity text-destructive"
                  onClick={() => eduField.remove(index)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
                <div className="grid grid-cols-2 gap-4 pr-8">
                  <div className="space-y-2 col-span-2 md:col-span-1">
                    <Label>Degree/Certificate</Label>
                    <Input {...register(`education.${index}.degree`)} placeholder="B.S. Computer Science" />
                  </div>
                  <div className="space-y-2 col-span-2 md:col-span-1">
                    <Label>Institution</Label>
                    <Input {...register(`education.${index}.institution`)} placeholder="State University" />
                  </div>
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input {...register(`education.${index}.startDate`)} placeholder="2016" />
                  </div>
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input {...register(`education.${index}.endDate`)} placeholder="2020" />
                  </div>
                </div>
              </div>
            ))}
            <Button variant="outline" className="w-full border-dashed" onClick={() => eduField.append({ degree: "", institution: "" })}>
              <Plus className="w-4 h-4 mr-2" /> Add Education
            </Button>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="skills" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Skills
          </AccordionTrigger>
          <AccordionContent className="space-y-4 pb-5">
            <div className="space-y-3">
              {skillsField.fields.map((field, index) => (
                <div key={field.id} className="flex gap-3 items-center group">
                  <div className="flex-1 space-y-1">
                    <Input {...register(`skills.${index}.name`)} placeholder="Skill name (e.g. React)" />
                  </div>
                  <Button variant="ghost" size="icon" className="opacity-0 group-hover:opacity-100 text-destructive" onClick={() => skillsField.remove(index)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full border-dashed" onClick={() => skillsField.append({ name: "" })}>
              <Plus className="w-4 h-4 mr-2" /> Add Skill
            </Button>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="social" className="bg-card border rounded-xl px-5 shadow-sm">
          <AccordionTrigger className="hover:no-underline font-semibold text-lg py-5">
            Social Links
          </AccordionTrigger>
          <AccordionContent className="space-y-4 pb-5">
            <div className="space-y-3">
              {socialField.fields.map((field, index) => (
                <div key={field.id} className="flex flex-col sm:flex-row gap-3 items-start sm:items-center group bg-muted/20 p-3 rounded-lg border">
                  <div className="w-full sm:w-1/3">
                    <Input {...register(`socialLinks.${index}.platform`)} placeholder="Platform (e.g. GitHub)" />
                  </div>
                  <div className="flex-1 w-full flex items-center gap-2">
                    <Input {...register(`socialLinks.${index}.url`)} placeholder="https://..." />
                    <Button variant="ghost" size="icon" className="text-destructive shrink-0" onClick={() => socialField.remove(index)}>
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <Button variant="outline" className="w-full border-dashed" onClick={() => socialField.append({ platform: "", url: "" })}>
              <Plus className="w-4 h-4 mr-2" /> Add Link
            </Button>
          </AccordionContent>
        </AccordionItem>
      </Accordion>
    </div>
  );
}
