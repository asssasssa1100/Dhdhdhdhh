import { useEffect, useRef, useState } from "react";
import { useGetCv, useUpdateCv, getGetCvQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { CvPatch } from "@workspace/api-client-react/src/generated/api.schemas";
import { useDebounce } from "./use-debounce";
import { toast } from "./use-toast";

export function useCvAutoSave(shareId: string, currentData: CvPatch, delay = 1000) {
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const debouncedData = useDebounce(currentData, delay);
  const updateCvMutation = useUpdateCv();
  const queryClient = useQueryClient();
  const initialMount = useRef(true);
  const lastSavedData = useRef(JSON.stringify(currentData));

  useEffect(() => {
    if (initialMount.current) {
      initialMount.current = false;
      return;
    }

    const dataString = JSON.stringify(debouncedData);
    if (dataString === lastSavedData.current) {
      return;
    }

    setSaveStatus("saving");
    updateCvMutation.mutate(
      { shareId, data: debouncedData },
      {
        onSuccess: (data) => {
          setSaveStatus("saved");
          lastSavedData.current = JSON.stringify(debouncedData);
          queryClient.setQueryData(getGetCvQueryKey(shareId), data);
          setTimeout(() => setSaveStatus("idle"), 2000);
        },
        onError: () => {
          setSaveStatus("error");
          toast({ title: "Failed to save changes", variant: "destructive" });
        }
      }
    );
  }, [debouncedData, shareId]);

  return { saveStatus };
}
