import { pgTable, text, serial, timestamp, integer, jsonb, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const cvsTable = pgTable("cvs", {
  id: serial("id").primaryKey(),
  shareId: text("share_id").notNull().unique(),
  name: text("name").notNull(),
  jobTitle: text("job_title").notNull(),
  bio: text("bio"),
  avatarUrl: text("avatar_url"),
  email: text("email"),
  phone: text("phone"),
  location: text("location"),
  website: text("website"),
  skills: jsonb("skills").notNull().default([]),
  experiences: jsonb("experiences").notNull().default([]),
  education: jsonb("education").notNull().default([]),
  socialLinks: jsonb("social_links").notNull().default([]),
  template: text("template").notNull().default("modern"),
  colorTheme: text("color_theme").notNull().default("blue"),
  language: text("language").notNull().default("en"),
  darkMode: boolean("dark_mode").notNull().default(false),
  viewCount: integer("view_count").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertCvSchema = createInsertSchema(cvsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  viewCount: true,
});
export type InsertCv = z.infer<typeof insertCvSchema>;
export type Cv = typeof cvsTable.$inferSelect;
